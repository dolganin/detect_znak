import os
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))
detect_znak_dir = os.path.join(current_dir, "../")
sys.path.append(detect_znak_dir)

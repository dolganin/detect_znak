import io
import numpy as np
import cv2
import onnxruntime
from sort.sort import *
from ultralytics import YOLO
from _paths import detect_znak_dir
from detect_znak import pipeline
from detect_znak.tools import unzip
from detect_znak.image_loaders import DumpyImageLoader
from sort.visualize import visualize_detections
from sort.util import get_car, read_license_plate, write_csv
from sort.add_missing_data import interp
from threading import Thread
from queue import Queue
        

class Detector():

    def __init__(self) -> None:
        """
        Initialize Detector object
        
        Args:
            None
        Returns:
            None
        """
        self.br = 0
        self.yolo = YOLO("yolov8n.pt")
        self.frame = []
        self.plate = {}
        path = os.path.join(detect_znak_dir, "detector")
        self.frame_nmr = -1
        # self.cap = cv2.VideoCapture('http://honjin1.miemasu.net/nphMotionJpeg?Resolution=640x480&Quality=Standard')
        self.queue = Queue(maxsize=1000)
        self.cap = cv2.VideoCapture('1.mp4')
        yolo_path = os.path.join(path, "yolov8n.onnx")
        self.yolo = YOLO(yolo_path)
        self.pipeline = pipeline("multiline_number_plate_detection_and_reading",image_loader=DumpyImageLoader)

    
    def forward(self, rgb_img):
        """
        Perform forward pass on the input image.

        Args:
            rgb_img (numpy.ndarray): Input RGB image.

        Returns:
            images (list): Original images
            images_bboxs (list): Bboxes predicted by YOLO
            images_points (list): Points predicted by CRAFT
            images_zones (list): Crop image(s) of predicted region(s)
            region_ids (list): Ids of predicted region class
            region_names (list): Names of predicted region class
            count_lines (list): count of predicted instances
            confidences (list): confidence scores for predictions
            predicted_image_texts (list): Predicted texts
        """
        return self.pipeline([rgb_img])
    
    def post_process(self, result):
        """
        Perform forward pass on the input image.

        Args:
            result (list): output from forward pass

        Returns:
            image (numpy.ndarray): Image with predictions drawn
            image_zones (list): Crop image(s) of predicted region(s)
            predicted_image_texts (list): Predicted texts
        """
        (images, images_bboxs, 
         images_points, images_zones, region_ids, 
         region_names, count_lines, 
         confidences, predicted_image_texts, read_confs) = unzip(result)
        for predicted_image_texts, \
            image, image_bboxs, \
            image_points, image_zones, \
            image_region_ids, image_region_names, \
            image_count_lines, \
            image_confidences in zip(predicted_image_texts,
                            images, images_bboxs,
                            images_points, images_zones,
                            region_ids, region_names,
                            count_lines, confidences):


            image = image.astype(np.uint8)
            for cntr in image_points:
                cntr = np.array(cntr, dtype=np.int32)
                try:
                    cv2.drawContours(image, [cntr], -1, (0, 0, 255), 2)
                except:
                    continue

            target_pixels = int(image.shape[0] * image.shape[1] * 0.01)

            check_color = (0, 255, 0)
            square_size = int(np.sqrt(target_pixels))
            rectangle_width = int(np.sqrt(target_pixels * 4.642857142857143))
            rectangle_height = int(np.sqrt(target_pixels / 4.642857142857143))
            square_width = int(np.sqrt(target_pixels * 1.705882353))
            square_height = int(np.sqrt(target_pixels / 1.705882353))

            cv2.rectangle(image, (0, 0), (square_width, square_height), check_color, 1)  
            cv2.rectangle(image, (0, 0), (rectangle_width, rectangle_height), check_color, 1)  
            cv2.putText(image, '1%', (10, round(image.shape[0]/25)), cv2.FONT_HERSHEY_PLAIN, (image.shape[0]/300), check_color, 1)

            for target_box in image_bboxs:
                cv2.rectangle(image,
                              (int(target_box[0]), int(target_box[1])),
                              (int(target_box[2]), int(target_box[3])),
                              (0, 255, 0),
                              1)
        return image, image_zones, predicted_image_texts, confidences, image_region_ids
    
    def _get_bbox_from_craft(self, cntr):
        x1, y1 = min(cntr[::2]), min(cntr[1::2])
        x2, y2 = max(cntr[::2]), max(cntr[1::2])
        return [x1, y1, x2, y2]
    
    def _get_bbox_from_detections(self, result):
        (images, images_bboxs, 
         images_points, images_zones, region_ids, 
         region_names, count_lines, 
         confidences, predicted_image_texts) = unzip(result)

        return images_bboxs
    
    def video_call(self, vid=None, interpolate=False):
        results = {}

        mot_tracker = Sort()
        if vid is not None:
            cap = cv2.VideoCapture(vid)
        ret = True
        vehicles = [2, 3, 5, 7]
        while ret:
            if self.br:
                exit()
            if vid is None:
                ret, frame = True, self.queue.get()
            if len(frame) == 0:
                    time.sleep(0.1)
                    continue
            self.frame_nmr += 1
            if ret:
                results[self.frame_nmr] = {}
                # detect vehicles

                # print(self.frame)
                detections = self.yolo(frame)[0]
                detections_ = []
                for detection in detections.boxes.data.tolist():
                    x1, y1, x2, y2, score, class_id = detection
                    if int(class_id) in vehicles:
                        detections_.append([x1, y1, x2, y2, score])
                print(detections_)
                # track vehicles
                try:
                    track_ids = mot_tracker.update(np.asarray(detections_))
                except:
                    print('IndexError: index 1 is out of bounds for axis 1 with size 1')
                    continue
                # detect license plates #CURRENT
                result = self.forward(frame)
                (images, images_bboxs, 
                 images_points, images_zones, region_ids, 
                 region_names, count_lines, 
                 confidences, predicted_image_texts, read_confs) = unzip(result)
#                 print(np.array(images_bboxs).shape)
                
                for i, license_plate in enumerate(images_bboxs[0]):
                    
                    x1, y1, x2, y2, score, class_id = license_plate

                    # assign license plate to car
                    xcar1, ycar1, xcar2, ycar2, car_id = get_car(license_plate, track_ids)
                    print(np.array(images_bboxs[0]).shape)
                    if car_id != -1:

                        if i >= len(predicted_image_texts[0]):
                            continue
                        # read license plate number
                        print(predicted_image_texts, read_confs, )
                        license_plate_text, license_plate_text_score = predicted_image_texts[0][i], read_confs[0][i]
                        print('===', license_plate_text, license_plate_text_score)
                        if license_plate_text is not None:
                            print(self.frame_nmr, 'LICENSE_PLATE', license_plate_text)
                            results[self.frame_nmr][car_id] = {'car': {'bbox': [xcar1, ycar1, xcar2, ycar2]},
                                                          'license_plate': {'bbox': [x1, y1, x2, y2],
                                                                            'text': license_plate_text,
                                                                            'bbox_score': score,
                                                                            'text_score': license_plate_text_score}}
                if not interpolate:
                    if self.frame_nmr !=0:
                        for res in track_ids:
                            xcar1, ycar1, xcar2, ycar2, car_id = res
                            prev = results[self.frame_nmr-1].get(car_id, None)
                            now = results[self.frame_nmr].get(car_id, None)
                            if prev is not None and now is None:
                                results[self.frame_nmr][car_id] = {'car': {'bbox': [xcar1, ycar1, xcar2, ycar2]},
                                                              'license_plate': {'bbox': [],
                                                                                'text': prev['license_plate']['text'],
                                                                                'bbox_score': prev['license_plate']['bbox_score'],
                                                                                'text_score': prev['license_plate']['text_score']}}
                if vid is None:

                    frame, self.plate = visualize_detections(results, "", frame, self.plate, self.frame_nmr)
                    print(self.plate)
                    cv2.imshow('second frame', frame)
                    cv2.waitKey(1)
        # write results
        #write_csv(results, './test.csv')
        if interpolate:
            file = interp('./test.csv')
        else:
            file = "./test.csv"
        if vid is not None:
            visualize_detections(results, vid)
    
    def run_cam(self):
        i = 0
        while True:
            ret, frame = self.cap.read()
            if ret:
                i = 0
                # cv2.imshow('frame',frame)
                # cv2.waitKey(1)
                self.queue.put(frame) 
            # else:
            #     i += 1
            #     if i > 50:
            #         self.br = 1
            #         exit('konec video')
                


        
    def __call__(self, rgb_img):
        return self.post_process(self.forward(rgb_img))
    
    def begin(self):
        try:
            Thread(target=self.run_cam).start()
        except Exception as e:
            print(f'{type(e).__name__}: CAMERA_DATA NOT FOUND')
        try:
            Thread(target=self.video_call,).start()
        except Exception as e:
            print(f'{type(e).__name__}: IMU_DATA NOT FOUND')
        # try:
        #     Thread(target=self.video_call, daemon=True).start()
        # except Exception as e:
        #     print(f'{type(e).__name__}: GPS_DATA NOT FOUND')
        # try:
        #     Thread(target=self.delete_subfolders).start()
        # except Exception as e:
        #     print(f'{type(e).__name__}: CHECK_FOLDER_SIZE CAN NOT WORK')
        # time.sleep(1)
        # try:
        #     Thread(target=self.server_run, daemon=True).start()
        # except Exception as e:
        #     print(f'{type(e).__name__}: CAN NOT RUN CAMERA SERVER')

if __name__ == '__main__':
        detector = Detector()
        detector.begin()

import cv2

cap = cv2.VideoCapture('http://pendelcam.kip.uni-heidelberg.de/mjpg/video.mjpg')
while True:
    while True:
            ret, frame = cap.read()
            if ret:
                print(frame)
                cv2.imshow('opg',frame)
                cv2.waitKey(1)
            else:
                 break